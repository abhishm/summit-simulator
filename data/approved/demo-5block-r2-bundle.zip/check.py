#!/usr/bin/env python3
import json
import os
import re
import sys
import zipfile
from datetime import datetime
from zoneinfo import ZoneInfo
import icalendar
import pypdf

BASE_DIR = "/workspace/summit"

STOPWORDS = {
    "about", "above", "after", "again", "against", "all", "almost", "alone", "along",
    "already", "also", "although", "always", "among", "around", "because", "become",
    "becomes", "becoming", "before", "behind", "being", "below", "beside", "besides",
    "between", "beyond", "both", "bottom", "cannot", "could", "During", "during",
    "either", "enough", "every", "everyone", "everything", "everywhere", "except",
    "fifteen", "fifty", "first", "five", "former", "formerly", "forty", "found",
    "four", "from", "front", "further", "Give", "hence", "hereafter", "hereby",
    "herein", "hereupon", "herself", "himself", "however", "hundred", "indeed",
    "inside", "instead", "into", "itself", "least", "less", "might", "more",
    "moreover", "most", "mostly", "much", "must", "myself", "namely", "neither",
    "never", "nevertheless", "next", "nine", "nobody", "none", "noone", "nothing",
    "nowhere", "often", "other", "others", "otherwise", "our", "ours", "ourselves",
    "perhaps", "please", "quite", "rather", "really", "regarding", "same", "seem",
    "seemed", "seeming", "seems", "several", "should", "since", "sixty", "some",
    "somehow", "someone", "something", "sometime", "sometimes", "somewhere", "still",
    "such", "their", "theirs", "them", "themselves", "then", "thence", "there",
    "thereafter", "thereby", "therefore", "therein", "thereupon", "these", "they",
    "thick", "thin", "third", "this", "those", "though", "three", "through",
    "throughout", "thru", "thus", "together", "toward", "towards", "twelve",
    "twenty", "under", "until", "upon", "very", "water", "whatever", "whence",
    "whenever", "where", "whereafter", "whereas", "whereby", "wherein", "whereupon",
    "wherever", "whether", "which", "while", "whither", "whole", "whom", "whose",
    "within", "without", "would", "yours", "yourself", "yourselves"
}


def distinctive_words(text):
    words = re.findall(r"[a-zA-Z]{5,}", text.lower())
    return {w for w in words if w not in STOPWORDS}


def word_tokens(text):
    return re.findall(r"[a-zA-Z0-9]+", text.lower())


def ngrams(tokens, n):
    if len(tokens) < n:
        return set()
    return {tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1)}


def split_sections(md_text):
    sections = {}
    current = "_header"
    sections[current] = []
    for line in md_text.splitlines():
        if line.startswith("## "):
            current = line.strip()
            sections[current] = []
        else:
            sections.setdefault(current, []).append(line)
    return {k: "\n".join(v) for k, v in sections.items()}


def main():
    schedule = json.load(open(os.path.join(BASE_DIR, "schedule.json")))
    guests_list = json.load(open(os.path.join(BASE_DIR, "guests.json")))
    guests = {g["id"]: g for g in guests_list}
    all_guest_ids = set(guests.keys())
    errors = []

    for gid, guest in guests.items():
        pkt_path = os.path.join(BASE_DIR, "packets", f"{gid}.md")
        if not os.path.exists(pkt_path):
            errors.append(f"[{gid}] Missing packet {pkt_path}")
            continue
        md_text = open(pkt_path, encoding="utf-8").read()
        sections = split_sections(md_text)

        # Check header
        expected_h1 = f"# {guest['title']} (`{gid}`)"
        first_line = md_text.splitlines()[0].strip() if md_text.splitlines() else ""
        if first_line != expected_h1:
            errors.append(f"[{gid}] Header mismatch: got '{first_line}', expected '{expected_h1}'")

        # Determine blocks attended and non-plenary counterparts
        attended_blocks = []
        non_plenary_counterparts = []
        for blk in schedule:
            for grp in blk["groups"]:
                if gid in grp["members"]:
                    others = [m for m in grp["members"] if m != gid]
                    attended_blocks.append((blk, grp, others))
                    if blk["format"] != "plenary":
                        for o in others:
                            if o not in non_plenary_counterparts:
                                non_plenary_counterparts.append(o)

        # 5a. Check "## Your day"
        your_day = sections.get("## Your day", "")
        day_lines = [ln.strip() for ln in your_day.splitlines() if ln.strip().startswith("- ")]
        if len(day_lines) != len(attended_blocks):
            errors.append(f"[{gid}] ## Your day has {len(day_lines)} bullets, expected {len(attended_blocks)}")

        for blk, grp, others in attended_blocks:
            prefix = f"{blk['start']}-{blk['end']} | {grp['room']} | {blk['title']}"
            matches = [ln for ln in day_lines if prefix in ln]
            if len(matches) != 1:
                errors.append(f"[{gid}] Block {blk['block']} expected exactly 1 matching line for '{prefix}', found {len(matches)}")
                continue
            ln = matches[0]
            if blk["format"] == "plenary":
                if "| with:" in ln:
                    errors.append(f"[{gid}] Plenary block {blk['block']} line must omit '| with: ...'")
            else:
                if "| with:" not in ln:
                    errors.append(f"[{gid}] Non-plenary block {blk['block']} line missing '| with: ...'")
                else:
                    with_part = ln.split("| with:", 1)[1]
                    mentioned_ids = {m for m in all_guest_ids if re.search(rf"\b{re.escape(m)}\b", with_part)}
                    expected_ids = set(others)
                    missing = expected_ids - mentioned_ids
                    extra = mentioned_ids - expected_ids
                    if missing or extra:
                        errors.append(f"[{gid}] Block {blk['block']} Your day ids mismatch: missing={missing}, extra={extra}")

        # 5b. Check "## Openings"
        openings_text = sections.get("## Openings", "")
        sub_map = {}
        curr_sub = None
        for ln in openings_text.splitlines():
            if ln.startswith("### "):
                curr_sub = ln.strip()
                sub_map[curr_sub] = []
            elif curr_sub is not None:
                sub_map[curr_sub].append(ln)

        all_opening_bullets = []
        for blk, grp, others in attended_blocks:
            if blk["format"] == "plenary":
                continue
            expected_sub_prefix = f"### Block {blk['block']}:"
            matching_subs = [k for k in sub_map if k.startswith(expected_sub_prefix)]
            if len(matching_subs) != 1:
                errors.append(f"[{gid}] Missing or duplicate subsection starting with '{expected_sub_prefix}' in ## Openings")
                continue
            sub_hdr = matching_subs[0]
            expected_hdr = f"### Block {blk['block']}: {blk['start']}-{blk['end']} | {grp['room']}"
            if sub_hdr != expected_hdr:
                errors.append(f"[{gid}] Subsection header '{sub_hdr}' != '{expected_hdr}'")
            bullets = [ln.strip() for ln in sub_map[sub_hdr] if ln.strip().startswith("- ")]
            if len(bullets) < 2:
                errors.append(f"[{gid}] Block {blk['block']} has {len(bullets)} bullets, need >= 2")
            expected_group_ids = set(others)
            outside_ids = all_guest_ids - expected_group_ids - {gid}

            # All co-participants' red_lines + tradeoffs combined
            grp_rl_tr_text = " ".join(
                " ".join(guests[o]["red_lines"] + guests[o]["tradeoffs"]) for o in others
            )
            grp_10grams = set()
            for o in others:
                for item in guests[o]["red_lines"] + guests[o]["tradeoffs"]:
                    grp_10grams |= ngrams(word_tokens(item), 10)

            for idx, b_text in enumerate(bullets, 1):
                all_opening_bullets.append(b_text)
                named_in_group = [o for o in others if re.search(rf"\b{re.escape(o)}\b", b_text)]
                named_outside = [o for o in outside_ids if re.search(rf"\b{re.escape(o)}\b", b_text)]
                if not named_in_group:
                    errors.append(f"[{gid}] Block {blk['block']} bullet {idx} names no co-participant id in group")
                if named_outside:
                    errors.append(f"[{gid}] Block {blk['block']} bullet {idx} names outside id(s): {named_outside}")

                # Check shared distinctive words with named co-participants' red_lines + tradeoffs (and group)
                named_rl_tr_text = " ".join(
                    " ".join(guests[o]["red_lines"] + guests[o]["tradeoffs"]) for o in named_in_group
                )
                b_words = distinctive_words(b_text)
                shared_named = b_words & distinctive_words(named_rl_tr_text)
                shared_grp = b_words & distinctive_words(grp_rl_tr_text)
                if len(shared_named) < 3 or len(shared_grp) < 3:
                    errors.append(
                        f"[{gid}] Block {blk['block']} bullet {idx} shares only {len(shared_named)} distinctive words with named co-participants ({shared_named})"
                    )

                # Check no 10-word run copied verbatim
                b_10grams = ngrams(word_tokens(b_text), 10)
                copied = b_10grams & grp_10grams
                if copied:
                    errors.append(f"[{gid}] Block {blk['block']} bullet {idx} has verbatim 10-word run: {copied}")

        # Check no 6-word phrase repeated in >= half (and >= 3) of packet's opening bullets
        phrase_counts = {}
        for b_text in all_opening_bullets:
            for ng in ngrams(word_tokens(b_text), 6):
                phrase_counts[ng] = phrase_counts.get(ng, 0) + 1
        threshold = max(3, (len(all_opening_bullets) + 1) // 2)
        for ng, cnt in phrase_counts.items():
            if cnt >= threshold:
                errors.append(f"[{gid}] Repeated 6-word phrase {ng} in {cnt}/{len(all_opening_bullets)} opening bullets")

        # 5c. Check "## Know your counterparts"
        kyc_text = sections.get("## Know your counterparts", "")
        kyc_bullets = [ln.strip() for ln in kyc_text.splitlines() if ln.strip().startswith("- ")]
        found_counterparts = []
        for ln in kyc_bullets:
            m = re.match(r"^-\s+\*\*([a-z0-9_]+)\*\*\s+\((.+?)\)\s+—\s+Top red line:\s+(.+?)\s+\|\s+Would trade:\s+(.+)$", ln)
            if not m:
                errors.append(f"[{gid}] Malformed counterpart bullet: {ln}")
                continue
            cid, ctitle, rl_part, tr_part = m.group(1), m.group(2), m.group(3), m.group(4)
            found_counterparts.append(cid)
            if cid not in guests:
                errors.append(f"[{gid}] Unknown counterpart id {cid}")
                continue
            c_guest = guests[cid]
            c_rl_words = distinctive_words(" ".join(c_guest["red_lines"]))
            c_tr_words = distinctive_words(" ".join(c_guest["tradeoffs"]))
            shared_rl = distinctive_words(rl_part) & c_rl_words
            shared_tr = distinctive_words(tr_part) & c_tr_words
            if len(shared_rl) < 2:
                errors.append(f"[{gid}] Counterpart {cid} red line shares < 2 distinctive words ({shared_rl})")
            if len(shared_tr) < 2:
                errors.append(f"[{gid}] Counterpart {cid} tradeoff shares < 2 distinctive words ({shared_tr})")

        if set(found_counterparts) != set(non_plenary_counterparts) or len(found_counterparts) != len(non_plenary_counterparts):
            errors.append(
                f"[{gid}] Counterparts mismatch: found={found_counterparts}, expected={non_plenary_counterparts}"
            )

        # 5d. Check ics/<id>.ics
        ics_path = os.path.join(BASE_DIR, "ics", f"{gid}.ics")
        if not os.path.exists(ics_path):
            errors.append(f"[{gid}] Missing {ics_path}")
        else:
            cal = icalendar.Calendar.from_ical(open(ics_path, "rb").read())
            events = [comp for comp in cal.walk() if comp.name == "VEVENT"]
            if len(events) != len(attended_blocks):
                errors.append(f"[{gid}] ICS has {len(events)} VEVENTs, expected {len(attended_blocks)}")
            tz = ZoneInfo("America/Los_Angeles")
            for (blk, grp, others), ev in zip(attended_blocks, events):
                sh, sm = map(int, blk["start"].split(":"))
                eh, em = map(int, blk["end"].split(":"))
                exp_start = datetime(2026, 11, 2, sh, sm, tzinfo=tz)
                exp_end = datetime(2026, 11, 2, eh, em, tzinfo=tz)
                dtstart = ev.decoded("DTSTART")
                dtend = ev.decoded("DTEND")
                loc = str(ev.get("LOCATION", ""))
                uid = str(ev.get("UID", ""))
                if dtstart != exp_start or dtend != exp_end or loc != grp["room"]:
                    errors.append(f"[{gid}] ICS block {blk['block']} mismatch: {dtstart}..{dtend} @ {loc}")
                if uid != f"{gid}-b{blk['block']}@demo-5block-r2":
                    errors.append(f"[{gid}] ICS block {blk['block']} UID mismatch: {uid}")

        # 5e. Check pdf/<id>.pdf
        pdf_path = os.path.join(BASE_DIR, "pdf", f"{gid}.pdf")
        if not os.path.exists(pdf_path):
            errors.append(f"[{gid}] Missing {pdf_path}")
        else:
            reader = pypdf.PdfReader(pdf_path)
            if len(reader.pages) < 1:
                errors.append(f"[{gid}] PDF has 0 pages")
            pdf_text = "\n".join(page.extract_text() or "" for page in reader.pages)
            if gid not in pdf_text:
                errors.append(f"[{gid}] PDF text missing guest id '{gid}'")
            for blk, _, _ in attended_blocks:
                if blk["start"] not in pdf_text:
                    errors.append(f"[{gid}] PDF text missing block start time '{blk['start']}'")

    # 5f. Check bundle.zip if present
    zip_path = os.path.join(BASE_DIR, "bundle.zip")
    if os.path.exists(zip_path):
        with zipfile.ZipFile(zip_path, "r") as zf:
            bad = zf.testzip()
            if bad is not None:
                errors.append(f"[bundle.zip] Corrupted file in zip: {bad}")
            names = set(zf.namelist())
            if "manifest.json" not in names:
                errors.append("[bundle.zip] Missing manifest.json")
            for gid in guests:
                for req in [f"packets/{gid}.md", f"ics/{gid}.ics", f"pdf/{gid}.pdf"]:
                    if req not in names:
                        errors.append(f"[bundle.zip] Missing {req}")

    if errors:
        print(f"FAILED with {len(errors)} error(s):")
        for e in errors:
            print(" -", e)
        sys.exit(1)
    else:
        zip_status = "including bundle.zip" if os.path.exists(zip_path) else "pre-zip"
        print(f"ALL CHECKS PASSED for {len(guests)} guests ({zip_status}): Your day, Openings, Know your counterparts, ICS, and PDF verified.")


if __name__ == "__main__":
    main()
